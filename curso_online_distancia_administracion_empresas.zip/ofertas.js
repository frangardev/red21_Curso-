// Textos de ofertas en las paginas de cursos

// Botón de WhatsApp
const ofertaWhatsApp = "75% de Descuento Escríbenos";
// Texto debajo del titulo de la página
const ofertaAbajoTitulo = "Si te inscribes antes del 9/1/2025 , participas de la promoción Año Nuevo 2025";
// Sección destacada debajo de temario
const ofertaAbajoTemario = "Si te inscribes antes del 9/1/2025 , recibirás un descuento del 75% + cursos complementarios gratuitos";
// Texto destacado en la sección de formas de pago e inscripción
const ofertaFormasDePago = "Si te inscribes antes del 10/1/2025 , recibirás un descuento del 40%";

// Descuento en porcentaje para calcular el precio final que se muestra en "Condiciones de Pago"
const descuento = 70; // Descuento en porcentaje

